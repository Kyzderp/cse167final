#include "Node.h"

Node::Node()
{

}

Node::~Node()
{

}

void Node::draw(GLuint shaderProgram, glm::mat4 C, glm::vec3 color)
{

}

void Node::update()
{

}