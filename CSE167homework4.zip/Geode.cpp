#include "Geode.h"

Geode::Geode()
{

}

Geode::~Geode()
{

}

void Geode::draw(GLuint shaderProgram, glm::mat4 C, glm::vec3 color)
{

}

void Geode::update()
{

}